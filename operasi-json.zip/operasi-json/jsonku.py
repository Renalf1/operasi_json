import json

class Jsonku:
    def __init__(self, buku):
        self.buku = buku

    def baca(self):
        try:
            with open(self.buku, 'r') as file:
                data = json.load(file)
            return data
        except FileNotFoundError:
            print("File tidak ditemukan.")
            return None
        except json.JSONDecodeError:
            print("Gagal membaca JSON. File mungkin tidak valid.")
            return None

    def tulis(self, data):
        try:
            with open(self.buku, 'w') as file:
                json.dump(data, file, indent=4)
            print("Data berhasil ditulis ke file.")
        except Exception as e:
            print(f"Terjadi kesalahan saat menulis ke file: {str(e)}")

    def update(self, key, value):
        data = self.baca()
        if data :
            data[key] = value
            self.tulis(data)
            print("Data berhasil diupdate")
        else :
            print("Tidak dapat melakukan update")

    def delete(self, key):
        data = self.baca()
        if data and key in data:
            del data[key]
            self.tulis(data)
            print(f"Data dengan kunci '{key}' berhasil dihapus.")
        else:
            print(f"Kunci '{key}' tidak ditemukan dalam data.")

if __name__ == "__main__":
    file = "data.json"
    jsonku = Jsonku(file)

jsonku.tulis({'Judul': 'Aku', "Pengarang": "Andi M.Ahmad", "Tahun_terbit": 2007, "Kota": "Malang"})

data = jsonku.baca()
print("Data sebelum update :", data)

jsonku.update("Tahun_terbit", 2005)
data = jsonku.baca()
print("Data setelah update Tahun_terbit :", data)

jsonku.delete("Kota")
data = jsonku.baca()
print("Data setelah penghapusan kota : ", data)